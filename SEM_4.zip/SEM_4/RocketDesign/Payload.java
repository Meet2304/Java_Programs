package SEM_4.RocketDesign;

public class Payload implements RocketDesign {

    @Override
    public void specs() {
        System.out.println("Starlink Communications Satellites");
    }
    
}
