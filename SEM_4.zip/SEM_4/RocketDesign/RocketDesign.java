package SEM_4.RocketDesign;

public interface RocketDesign {
    public void specs();    
}



