package SEM_4.RocketDesign;

public class Booster implements RocketDesign{

    @Override
    public void specs() {
        System.out.println("Starship Booster");
        System.out.println("33 Raptor Engines");
    }

}
