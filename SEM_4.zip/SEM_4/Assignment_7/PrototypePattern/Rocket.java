package SEM_4.Assignment_7.PrototypePattern;

interface Rocket extends Cloneable {
    Rocket clone();
    void ignite();
}

