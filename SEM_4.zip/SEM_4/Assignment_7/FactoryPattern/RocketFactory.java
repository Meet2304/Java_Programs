package SEM_4.Assignment_7.FactoryPattern;

interface RocketFactory {
    Rocket createRocket();
}

