package SEM_4.Assignment_7.FactoryPattern;

class SpaceXRocket implements Rocket {
    public void ignite() {
        System.out.println("SpaceX Rocket ignited!");
    }
}
