package SEM_4.Abstract_Design_Pattern.Rocket;

interface RocketFactory {
    Engine setEngine();
    Payload setPayload();
}
