package SEM_4.Abstract_Design_Pattern.Rocket;

public class Perigrine implements Payload{
    @Override
    public void DisplayPayload() {
        System.out.println("Payload: Perigrine");
    }
}
