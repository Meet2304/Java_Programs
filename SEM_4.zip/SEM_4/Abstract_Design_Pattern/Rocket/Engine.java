package SEM_4.Abstract_Design_Pattern.Rocket;

interface Engine {
    void DisplayEngine();
}
