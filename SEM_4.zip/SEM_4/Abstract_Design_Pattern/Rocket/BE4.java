package SEM_4.Abstract_Design_Pattern.Rocket;

public class BE4 implements Engine {
    @Override
    public void DisplayEngine() {
        System.out.println("BE4 Engine");
    }
}
