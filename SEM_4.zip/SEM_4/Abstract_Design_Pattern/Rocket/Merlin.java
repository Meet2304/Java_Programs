package SEM_4.Abstract_Design_Pattern.Rocket;

public class Merlin implements Engine {
    @Override
    public void DisplayEngine() {
        System.out.println("Merlin Engine");
    }
}
