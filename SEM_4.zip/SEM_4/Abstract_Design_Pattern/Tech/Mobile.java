package SEM_4.Abstract_Design_Pattern.Tech;

interface Mobile {
    void DisplayInfo();
}
