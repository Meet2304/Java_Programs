package SEM_4.Abstract_Design_Pattern.Tech;

public class Windows implements OS {
    
    @Override
    public void DisplayOS() {
        System.out.println("Windows Operating System");
    }
}
