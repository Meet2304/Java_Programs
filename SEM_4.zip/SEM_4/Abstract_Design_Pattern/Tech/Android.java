package SEM_4.Abstract_Design_Pattern.Tech;

public class Android implements OS {

    @Override
    public void DisplayOS() {
        System.out.println("Android Operating System");
    }
    
}
