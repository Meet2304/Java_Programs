package SEM_4.Abstract_Design_Pattern.Tech;

public class SamsungMobile implements Mobile{

    @Override
    public void DisplayInfo() {
        System.out.println("Samsung Mobile");
    }
    
}
