package SEM_4.Abstract_Design_Pattern.Tech;

public class IOS implements OS {
    @Override
    public void DisplayOS() {
        System.out.println("IOS Operating System");
    }
}
