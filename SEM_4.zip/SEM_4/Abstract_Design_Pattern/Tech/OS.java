package SEM_4.Abstract_Design_Pattern.Tech;
// Abstract Product 1 - OS
interface OS {
    void DisplayOS();
}
