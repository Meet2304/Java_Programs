package SEM_4.Abstract_Design_Pattern.Tech;

interface MobileFactory {
    Mobile CreateMobile();
    OS CreateOS();
}
