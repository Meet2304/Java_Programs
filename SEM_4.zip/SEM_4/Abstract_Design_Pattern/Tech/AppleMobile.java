package SEM_4.Abstract_Design_Pattern.Tech;

public class AppleMobile implements Mobile {
    @Override
    public void DisplayInfo() {
        System.out.println("Apple Mobile");
    }
}
