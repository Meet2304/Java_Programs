package SEM_4.Abstract_Design_Pattern.Tech;

public class NokiaMobile implements Mobile {
    @Override
    public void DisplayInfo() {
        System.out.println("Nokia Mobile");
    }
}
