package SEM_4.Abstract_Design_Pattern.Restaurant;

public class Mexican implements Cusine{
    @Override
    public void displayCusine() {
        System.out.println("Mexican Cusine");
    }
}
