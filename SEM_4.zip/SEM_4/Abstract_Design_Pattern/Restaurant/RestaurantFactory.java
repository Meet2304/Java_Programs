package SEM_4.Abstract_Design_Pattern.Restaurant;

interface RestaurantFactory {
    Type RestaurantType();
    Cusine RestaurantCusine();
}
