package SEM_4.Abstract_Design_Pattern.Restaurant;

public class Cafe implements Type {

    @Override
    public void displayType() {
        System.out.println("Type: Cafe");
    }
}
