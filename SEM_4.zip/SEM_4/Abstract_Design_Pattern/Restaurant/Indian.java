package SEM_4.Abstract_Design_Pattern.Restaurant;

public class Indian implements Cusine{

    @Override
    public void displayCusine() {
        System.out.println("Indian Cusine");
    }
    
}
