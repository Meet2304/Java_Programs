package SEM_4.Abstract_Design_Pattern.Restaurant;

interface Cusine {
    void displayCusine();
}
