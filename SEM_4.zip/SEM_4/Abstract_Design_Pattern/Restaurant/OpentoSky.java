package SEM_4.Abstract_Design_Pattern.Restaurant;

public class OpentoSky implements Type {
    @Override
    public void displayType() {
        System.out.println("Type: Open to Sky");
    }
}
