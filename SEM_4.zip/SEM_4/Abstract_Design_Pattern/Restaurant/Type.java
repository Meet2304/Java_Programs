package SEM_4.Abstract_Design_Pattern.Restaurant;

interface Type {
    void displayType();
}
