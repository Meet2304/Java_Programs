package SEM_4.Abstract_Design_Pattern.Restaurant;

public class Italian implements Cusine {
    @Override
    public void displayCusine() {
        System.out.println("Italian Cusine");
    }
}
